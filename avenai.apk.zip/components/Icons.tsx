
import React from 'react';

export const SendIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
  >
    <path d="M3.478 2.405a.75.75 0 00-.926.94l2.432 7.905H13.5a.75.75 0 010 1.5H4.984l-2.432 7.905a.75.75 0 00.926.94 60.519 60.519 0 0018.445-8.986.75.75 0 000-1.218A60.517 60.517 0 003.478 2.405z" />
  </svg>
);

export const PlusIcon = ({ className }: { className?: string }) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 24 24" 
        fill="currentColor" 
        className={className}>
        <path fillRule="evenodd" d="M12 3.75a.75.75 0 01.75.75v6.75h6.75a.75.75 0 010 1.5h-6.75v6.75a.75.75 0 01-1.5 0v-6.75H4.5a.75.75 0 010-1.5h6.75V4.5a.75.75 0 01.75-.75z" clipRule="evenodd" />
    </svg>
);

export const AiIcon = ({ className }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path fillRule="evenodd" d="M9 4.5a.75.75 0 01.75.75v3.546l.065-.054a3 3 0 013.64 4.008l-1.21 1.21a.75.75 0 01-1.06-1.06l1.21-1.21a1.5 1.5 0 00-1.82-2.004l-.065.054V9.75a.75.75 0 01-1.5 0V5.25A.75.75 0 019 4.5z" clipRule="evenodd" />
        <path d="M3 10.5a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0zm1.5-4.5a1.5 1.5 0 100 3 1.5 1.5 0 000-3zm10.5 1.5a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0zm1.5-4.5a1.5 1.5 0 100 3 1.5 1.5 0 000-3zM15 12a1.5 1.5 0 100 3 1.5 1.5 0 000-3zm-1.5 4.5a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0z" />
        <path fillRule="evenodd" d="M6.323 15.977a.75.75 0 011.06 0l1.21 1.21a1.5 1.5 0 002.122 0l4.596-4.596a1.5 1.5 0 012.122 0l1.21 1.21a.75.75 0 11-1.061 1.06l-1.21-1.21a1.5 1.5 0 00-2.121 0l-4.596 4.596a1.5 1.5 0 01-2.122 0l-1.21-1.21a.75.75 0 010-1.06z" clipRule="evenodd" />
    </svg>
);

export const UserIcon = ({ className }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path fillRule="evenodd" d="M7.5 6a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0zM3.751 20.105a8.25 8.25 0 0116.498 0 .75.75 0 01-.437.695A18.683 18.683 0 0112 22.5c-2.786 0-5.433-.608-7.812-1.7a.75.75 0 01-.437-.695z" clipRule="evenodd" />
    </svg>
);

export const LoadingSpinner = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`animate-spin ${className}`}
  >
    <path d="M21 12a9 9 0 1 1-6.219-8.56" />
  </svg>
);

export const CopyIcon = ({ className }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path fillRule="evenodd" d="M10.5 3A2.25 2.25 0 008.25 5.25v.54l-1.06-1.06a.75.75 0 00-1.06 1.06L7.25 7.9l-.82.82a.75.75 0 001.06 1.06l1.06-1.06 1.59 1.59a.75.75 0 001.06 0l4.5-4.5a.75.75 0 00-1.06-1.06l-3.97 3.97-.68-.68A2.25 2.25 0 0010.5 3zM13.5 7.5a.75.75 0 00-1.06-1.06l-1.06 1.06a.75.75 0 000 1.06l1.06 1.06a.75.75 0 001.06 0l3-3a.75.75 0 00-1.06-1.06l-2.47 2.47-.68-.68a.75.75 0 00-1.06 0l-.68.68.68.68a.75.75 0 101.06 1.06l.68-.68.68.68-.68.68a.75.75 0 101.06 1.06l.68-.68.68.68a.75.75 0 101.06 1.06l-3.97-3.97-.68.68.68.68a.75.75 0 101.06 1.06l2.47-2.47L18.62 12l.82-.82a.75.75 0 00-1.06-1.06l-1.06 1.06-1.59-1.59a.75.75 0 00-1.06 0l-1.59 1.59a.75.75 0 000 1.06l.68.68-.68.68a.75.75 0 101.06 1.06l.68-.68.68.68a.75.75 0 101.06 1.06L15 13.56l-1.59 1.59a.75.75 0 000 1.06l1.06 1.06a.75.75 0 001.06 0l4.5-4.5a.75.75 0 00-1.06-1.06L18 12.94l.68-.68a.75.75 0 000-1.06l-.68-.68-.68.68a.75.75 0 000 1.06l.68.68a.75.75 0 101.06 1.06l.68-.68a.75.75 0 101.06 1.06l-3 3a.75.75 0 001.06 1.06l3.97-3.97a2.25 2.25 0 000-3.18l-4.24-4.24A2.25 2.25 0 0013.5 7.5z" clipRule="evenodd" />
      <path d="M9 19.5a2.25 2.25 0 01-2.25-2.25V10.9l-1.06 1.06a.75.75 0 01-1.06-1.06l1.06-1.06a.75.75 0 011.06 0l1.06 1.06-1.06 1.06a.75.75 0 01-1.06 1.06l-.82-.82-2.18 2.18a.75.75 0 01-1.06-1.06l2.18-2.18.82-.82a.75.75 0 011.06 0l.82.82a2.25 2.25 0 013.18 0l4.24 4.24a2.25 2.25 0 010 3.18l-4.24 4.24A2.25 2.25 0 019 19.5z" />
    </svg>
);

export const MessageIcon = ({ className }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path fillRule="evenodd" d="M4.848 2.771A49.144 49.144 0 0112 2.25c2.43 0 4.817.178 7.152.52 1.978.292 3.348 2.024 3.348 3.97v6.02c0 1.946-1.37 3.678-3.348 3.97a48.901 48.901 0 01-3.476.382.75.75 0 00-.676.65L15 21.75H9.75l-.676-4.873a.75.75 0 00-.676-.65 48.9 48.9 0 01-3.476-.382c-1.978-.292-3.348-2.024-3.348-3.97V6.741c0-1.946 1.37-3.678 3.348-3.97zM6.75 8.25a.75.75 0 01.75-.75h9a.75.75 0 010 1.5h-9a.75.75 0 01-.75-.75zm.75 2.25a.75.75 0 000 1.5H12a.75.75 0 000-1.5H7.5z" clipRule="evenodd" />
    </svg>
);

export const TrashIcon = ({ className }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path fillRule="evenodd" d="M16.5 4.478v.227a48.816 48.816 0 013.878.512.75.75 0 11-.256 1.478l-.209-.035-1.005 13.006a.75.75 0 01-.75.75H5.634a.75.75 0 01-.75-.75L3.89 6.66l-.209.035a.75.75 0 01-.256-1.478A48.567 48.567 0 017.5 4.705v-.227c0-1.564 1.213-2.9 2.816-2.951a52.662 52.662 0 013.369 0c1.603.051 2.815 1.387 2.815 2.951zm-6.136-1.452a51.196 51.196 0 013.273 0C14.39 3.05 15 3.684 15 4.478v.113a49.488 49.488 0 00-6 0v-.113c0-.794.609-1.428 1.364-1.452zm-.355 5.945a.75.75 0 10-1.5.058l.347 9a.75.75 0 101.499-.058l-.347-9zm5.48.058a.75.75 0 10-1.499-.058l-.347 9a.75.75 0 001.5.058l.346-9z" clipRule="evenodd" />
    </svg>
);