
import React from 'react';
import type { Note } from '../types';
import { MessageIcon, TrashIcon } from './Icons';

interface NoteItemProps {
  note: Note;
  isActive: boolean;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
}

const NoteItem: React.FC<NoteItemProps> = ({ note, isActive, onSelect, onDelete }) => {
  const formattedDate = new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }).format(note.createdAt);

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent onSelect from firing
    onDelete(note.id);
  };

  return (
    <div className="relative group">
      <button
        onClick={() => onSelect(note.id)}
        className={`w-full text-left p-3 rounded-lg transition-colors duration-200 ${
          isActive ? 'bg-blue-600/30' : 'hover:bg-gray-700/50'
        }`}
      >
        <div className="flex items-center gap-3">
          <MessageIcon className="w-5 h-5 text-gray-400 flex-shrink-0" />
          <div className="flex-1 overflow-hidden">
            <p className="font-medium text-gray-200 truncate pr-8">{note.title}</p>
            <p className="text-xs text-gray-500">{formattedDate}</p>
          </div>
        </div>
      </button>
      <button
        onClick={handleDelete}
        className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-md text-gray-500 hover:text-red-400 hover:bg-gray-600/50 opacity-0 group-hover:opacity-100 focus:opacity-100 transition-all duration-200"
        aria-label={`Delete note: ${note.title}`}
      >
        <TrashIcon className="w-4 h-4" />
      </button>
    </div>
  );
};

export default NoteItem;
