import { GoogleGenAI } from "@google/genai";
import type { Message, Source } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// We will not use the chat session here to keep the service stateless.
// The App component will manage the full conversation history for each note.
export const getAiResponse = async (prompt: string, history: Message[]): Promise<{text: string, sources?: Source[]}> => {
  try {
    // The Gemini API requires a specific format for conversation history.
    // It should be an array of { role, parts: [{ text }] } objects.
    const formattedHistory = history.map(msg => ({
      role: msg.role,
      parts: [{ text: msg.text }],
    }));

    const result = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [...formattedHistory, { role: 'user', parts: [{ text: prompt }] }],
        config: {
            temperature: 0.7,
            topP: 0.95,
            topK: 64,
            tools: [{googleSearch: {}}],
            systemInstruction: "You are Aven Ai, a helpful and powerful AI assistant similar to ChatGPT. Please format your responses using Markdown. Use headings, lists, code blocks, and other elements to make the information clear and readable. When you use your search tool, the information will be cited for you."
        }
    });

    const responseText = result.text;
    const groundingMetadata = result.candidates?.[0]?.groundingMetadata;
    
    let sources: Source[] = [];
    if (groundingMetadata?.groundingChunks) {
        sources = groundingMetadata.groundingChunks
            .map((chunk: any) => chunk.web)
            .filter((source: any): source is Source => source?.uri && source?.title);
    }
    
    return { text: responseText, sources: sources.length > 0 ? sources : undefined };
  } catch (error) {
    console.error("Error getting AI response:", error);
    return { text: "Sorry, I encountered an error. Please try again. Check if your API key is configured correctly."};
  }
};