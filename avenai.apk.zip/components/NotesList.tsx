
import React from 'react';
import type { Note } from '../types';
import NoteItem from './NoteItem';
import { PlusIcon, AiIcon } from './Icons';

interface NotesListProps {
  notes: Note[];
  activeNoteId: string | null;
  onSelectNote: (id: string) => void;
  onNewChat: () => void;
  onDeleteNote: (id: string) => void;
}

const NotesList: React.FC<NotesListProps> = ({
  notes,
  activeNoteId,
  onSelectNote,
  onNewChat,
  onDeleteNote,
}) => {
  return (
    <div className="w-80 bg-gray-900 h-full flex flex-col p-3 border-r border-gray-800">
      <div className="flex items-center gap-3 p-3 mb-4">
        <AiIcon className="w-8 h-8 text-blue-500" />
        <h1 className="text-xl font-bold text-white">AI Notes</h1>
      </div>
      <button
        onClick={onNewChat}
        className="w-full flex items-center justify-center gap-2 mb-4 px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
      >
        <PlusIcon className="w-5 h-5" />
        New Chat
      </button>
      <div className="flex-1 overflow-y-auto pr-1">
        <div className="space-y-1">
            {notes.length > 0 ? (
                notes.map((note) => (
                    <NoteItem
                        key={note.id}
                        note={note}
                        isActive={note.id === activeNoteId}
                        onSelect={onSelectNote}
                        onDelete={onDeleteNote}
                    />
                ))
            ) : (
                <div className="text-center text-gray-500 px-4 py-8">
                    <p>No notes yet.</p>
                    <p className="text-sm">Start a new chat to save your first note!</p>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default NotesList;
