import React, { useEffect, useRef, useState } from 'react';
import type { Message } from '../types';
import ChatInput from './ChatInput';
import { AiIcon, UserIcon, LoadingSpinner, CopyIcon } from './Icons';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeRaw from 'rehype-raw';

interface ChatViewProps {
  messages: Message[];
  onSendMessage: (message: string) => void;
  isLoading: boolean;
}

const WelcomeScreen: React.FC = () => (
    <div className="flex flex-col items-center justify-center h-full text-center text-gray-400 p-4">
        <AiIcon className="w-20 h-20 sm:w-24 sm:h-24 mb-6 text-blue-500" />
        <h1 className="text-3xl sm:text-4xl font-bold text-gray-200 mb-2">Aven Ai</h1>
        <p className="max-w-md text-sm sm:text-base">Your simple and fast AI assistant. Start by asking a question below.</p>
        <p className="mt-8 text-2xl font-bold text-gray-500 font-dancing-script">- Sahil Pathaan -</p>
    </div>
);

const CodeBlock: React.FC<any> = ({ node, inline, className, children, ...props }) => {
    const [isCopied, setIsCopied] = useState(false);
    const match = /language-(\w+)/.exec(className || '');
    const language = match ? match[1] : 'text';

    const handleCopy = () => {
        const codeString = String(children).replace(/\n$/, '');
        navigator.clipboard.writeText(codeString);
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
    };

    return !inline ? (
        <div className="bg-gray-900/70 rounded-lg my-4 overflow-hidden shadow-lg">
            <div className="flex justify-between items-center px-4 py-1.5 bg-gray-700/50 text-xs text-gray-400">
                <span className="font-sans">{language}</span>
                <button 
                    onClick={handleCopy} 
                    className="flex items-center gap-1.5 text-gray-400 hover:text-white transition-colors"
                    aria-label="Copy code"
                >
                    {isCopied ? (
                        <>
                            <span className="text-emerald-400">Copied!</span>
                        </>
                    ) : (
                        <>
                            <CopyIcon className="w-4 h-4" />
                            <span>Copy code</span>
                        </>
                    )}
                </button>
            </div>
            <pre className="p-4 overflow-x-auto text-sm">
                <code className={`language-${language}`} {...props}>
                    {children}
                </code>
            </pre>
        </div>
    ) : (
        <code className="bg-gray-700/80 text-red-300 rounded-md px-1.5 py-1 font-mono text-sm" {...props}>
            {children}
        </code>
    );
};


const MessageBubble: React.FC<{ message: Message }> = ({ message }) => {
    const isUser = message.role === 'user';
    
    const markdownComponents = {
        h1: (props) => <h1 className="text-2xl font-bold my-4" {...props} />,
        h2: (props) => <h2 className="text-xl font-bold my-3" {...props} />,
        h3: (props) => <h3 className="text-lg font-bold my-2" {...props} />,
        p: (props) => <p className="mb-4 last:mb-0" {...props} />,
        a: (props) => <a className="text-blue-400 underline hover:text-blue-300" target="_blank" rel="noopener noreferrer" {...props} />,
        ul: (props) => <ul className="list-disc list-inside mb-4 pl-4" {...props} />,
        ol: (props) => <ol className="list-decimal list-inside mb-4 pl-4" {...props} />,
        li: (props) => <li className="mb-1" {...props} />,
        code: CodeBlock,
        pre: ({children}) => <>{children}</>,
        blockquote: (props) => <blockquote className="border-l-4 border-gray-500 pl-4 italic my-4 text-gray-400" {...props} />,
    };

    return (
        <div className={`flex items-start gap-3 sm:gap-4 ${isUser ? 'justify-end' : ''}`}>
            {!isUser && (
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0">
                    <AiIcon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                </div>
            )}
            <div className={`max-w-2xl px-4 py-3 sm:px-5 rounded-2xl ${isUser ? 'bg-blue-600 text-white rounded-br-lg' : 'bg-gray-700 text-gray-200 rounded-bl-lg'}`}>
                {isUser ? (
                     <p className="whitespace-pre-wrap">{message.text}</p>
                ) : (
                    <>
                        <ReactMarkdown
                            rehypePlugins={[rehypeRaw]}
                            remarkPlugins={[remarkGfm]}
                            components={markdownComponents}
                        >
                            {message.text}
                        </ReactMarkdown>
                        {message.sources && message.sources.length > 0 && (
                            <div className="mt-4 pt-3 border-t border-gray-600">
                                <h4 className="text-xs font-semibold text-gray-400 mb-2">Sources:</h4>
                                <div className="flex flex-col gap-2">
                                    {message.sources.map((source, index) => (
                                        <a 
                                            key={index} 
                                            href={source.uri} 
                                            target="_blank" 
                                            rel="noopener noreferrer" 
                                            className="text-xs text-blue-400 hover:underline truncate block w-full"
                                            title={source.title}
                                        >
                                            {`[${index + 1}] ${source.title}`}
                                        </a>
                                    ))}
                                </div>
                            </div>
                        )}
                    </>
                )}
            </div>
             {isUser && (
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-gray-600 flex items-center justify-center flex-shrink-0">
                    <UserIcon className="w-5 h-5 sm:w-6 sm:h-6 text-gray-300" />
                </div>
            )}
        </div>
    );
};

const ChatView: React.FC<ChatViewProps> = ({ messages, onSendMessage, isLoading }) => {
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages, isLoading]);


    return (
        <div className="flex flex-col h-full bg-gray-800 text-white">
            <main className="flex-1 overflow-y-auto p-4 sm:p-6">
                <div className="max-w-4xl mx-auto">
                    {messages.length > 0 ? (
                        <div className="space-y-6">
                            {messages.map((msg, index) => (
                                <MessageBubble key={index} message={msg} />
                            ))}
                            {isLoading && (
                                <div className="flex items-start gap-3 sm:gap-4">
                                     <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0">
                                        <AiIcon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                                    </div>
                                    <div className="max-w-2xl px-5 py-3 rounded-2xl bg-gray-700 text-gray-200 rounded-bl-lg flex items-center">
                                        <LoadingSpinner className="w-5 h-5 mr-3" />
                                        <span>Thinking...</span>
                                    </div>
                                </div>
                            )}
                            <div ref={messagesEndRef} />
                        </div>
                    ) : (
                        <WelcomeScreen />
                    )}
                </div>
            </main>
            <ChatInput onSendMessage={onSendMessage} isLoading={isLoading} />
        </div>
    );
};

export default ChatView;