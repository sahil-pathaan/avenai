import React, { useEffect } from 'react';

// This allows us to access adsbygoogle on the window object without TypeScript errors.
declare global {
    interface Window {
        adsbygoogle: any[];
    }
}

interface AdBannerProps {
  adSlot: string;
  adClient: string;
}

/**
 * A component to display a Google AdSense banner.
 * It's designed to be responsive and automatically fetch an ad.
 */
const AdBanner: React.FC<AdBannerProps> = ({ adSlot, adClient }) => {
  useEffect(() => {
    // We use requestAnimationFrame to wait for the next paint,
    // which helps ensure that the ad container has been rendered and has a width.
    // This is a robust way to prevent the "No slot size for availableWidth=0" error.
    const handle = requestAnimationFrame(() => {
        try {
            (window.adsbygoogle = window.adsbygoogle || []).push({});
        } catch (e) {
            console.error('AdSense error:', e);
        }
    });

    return () => cancelAnimationFrame(handle);
  }, [adClient, adSlot]); // Re-run if props change

  // This container sets the size for the ad banner.
  // The background has been removed to make it transparent until the ad loads.
  return (
    <div className="w-full max-w-2xl min-h-[90px] mx-auto rounded-lg overflow-hidden">
        <ins className="adsbygoogle"
             style={{ display: 'block', width: '100%' }}
             data-ad-client={adClient}
             data-ad-slot={adSlot}
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
    </div>
  );
};

export default AdBanner;